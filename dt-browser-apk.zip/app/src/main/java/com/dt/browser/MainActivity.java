package com.dt.browser;

import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.WebStorage;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Enable cookie management
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(null);

        // Launch the actual browser activity
        BrowserActivity.launch(this);
        finish();
    }
}
