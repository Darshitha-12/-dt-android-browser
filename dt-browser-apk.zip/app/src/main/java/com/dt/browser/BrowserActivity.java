package com.dt.browser;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.util.Base64;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.ClientCertRequest;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.HttpAuthHandler;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.SafeBrowsingResponse;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewAssetLoader;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class BrowserActivity extends AppCompatActivity {

    // ── Tab system ──
    static class Tab {
        String id;
        WebView webView;
        String url;
        String title;
        Bitmap favicon;
        boolean isLoading;
        Tab(String id, WebView wv, String url) {
            this.id = id; this.webView = wv; this.url = url; this.title = ""; this.isLoading = true;
        }
    }

    private List<Tab> tabs = new ArrayList<>();
    private String activeTabId = null;
    private FrameLayout webViewContainer;
    private LinearLayout tabBar;
    private EditText urlBar;
    private ProgressBar progressBar;
    private ImageButton btnBack, btnForward, btnRefresh, btnTabs, btnMenu;

    // ── Ad blocking ──
    private static final String[] AD_HOSTS = {
        "doubleclick", "googlesyndication", "adnxs", "moatads", "taboola", "outbrain",
        "ads.youtube", "advertising.com",
        "pagead2.googlesyndication.com", "static.doubleclick.net", "ad.doubleclick.net",
        "ads.google.com", "googleadservices", "googletagmanager.com", "googletagservices",
        "google-analytics.com", "ads-twitter.com", "ads.twitter.com",
        "amazon-adsystem", "media.net", "rubiconproject",
        "openx.net", "pubmatic.com", "criteo.com", "appnexus.com",
        "adsrvr.org", "eyeota.net", "scorecardresearch", "quantserve",
        "bluekai.com", "krxd.net", "demdex.net", "omtrdc.net",
        "adobedtm.com", "adsafeprotected.com", "casalemedia.com",
        "youtube.com/pagead", "youtube.com/api/stats/ads",
        "ads-youtube.com", "youtubei.googleapis.com/youtubei/v1/log"
    };

    private static final String YT_AD_SCRIPT = "(function(){if(window.__DT_AD__)return;window.__DT_AD__=true;try{Object.defineProperty(window,'ytInitialPlayerResponse',{get:function(){return window.__dtYtVal},set:function(v){if(v){if(v.adPlacements)v.adPlacements=[];if(v.playerAds)v.playerAds=[]}window.__dtYtVal=v},configurable:true})}catch(e){}try{var f=window.fetch;window.fetch=function(r,o){var u=(typeof r=='string'?r:(r&&r.url))||'';return f.apply(this,arguments).then(function(r){if(u.indexOf('/youtubei/v1/player')>=0||u.indexOf('/youtubei/v1/next')>=0){return r.text().then(function(b){try{var d=JSON.parse(b),c=false;if(d.adPlacements){d.adPlacements=[];c=true}if(d.playerAds){d.playerAds=[];c=true}if(c){var h=new Headers();r.headers.forEach(function(v,k){if(k!='content-encoding'&&k!='content-length')h.set(k,v)});return new Response(JSON.stringify(d),{status:r.status,statusText:r.statusText,headers:h})}}catch(e){}return r}).catch(function(){return r})}return r})}catch(e){}try{var _x=XMLHttpRequest.prototype.open,_s=XMLHttpRequest.prototype.send;XMLHttpRequest.prototype.open=function(m,u){this.__dtUrl=u||'';return _x.apply(this,arguments)};XMLHttpRequest.prototype.send=function(){var x=this;if(x.__dtUrl&&(x.__dtUrl.indexOf('/youtubei/v1/player')>=0||x.__dtUrl.indexOf('/youtubei/v1/next')>=0)){x.addEventListener('readystatechange',function(){if(x.readyState==4){try{var b=x.responseText;if(b){var d=JSON.parse(b),c=false;if(d.adPlacements){d.adPlacements=[];c=true}if(d.playerAds){d.playerAds=[];c=true}if(c){var s=JSON.stringify(d);Object.defineProperty(x,'responseText',{value:s,writable:false});Object.defineProperty(x,'response',{value:s,writable:false})}}}catch(e){}}})}return _s.apply(this,arguments)}}catch(e){}try{if(window.yt&&window.yt.config_){window.yt.config_.ADS_ENABLED=false;window.yt.config_.DELEGATED_AD_ID='';window.yt.config_.allow_ads=false}}catch(e){}function c(){try{document.querySelectorAll('#masthead-ad,#player-ads,.ytp-ad-overlay-container,.ytp-ad-player-overlay,.ytp-ad-image-overlay,.ytp-ad-text-overlay,.ytp-ad-action-interstitial,ytd-ad-slot-renderer,.ytp-ad-progress-list,.ytp-ad-survey-player-overlay,ytd-in-feed-ad-layout-renderer,.ytd-action-companion-ad-renderer,.ytp-ad-preview-text,.ytp-ad-simple-ad-badge,.ytp-ad-preview-container,ytd-display-ad-renderer,.ytp-ad-player-overlay-flyout-cta,.video-ads').forEach(function(e){if(e&&e.parentNode)e.remove()})}catch(e){}}function s(){try{var b=document.querySelector('.ytp-ad-skip-button,.ytp-skip-ad-button,.ytp-ad-skip-button-modern,.ytp-ad-skip-button-container button');if(b&&b.offsetParent!==null)b.click()}catch(e){}}c();setInterval(function(){c();s()},200);var o=new MutationObserver(function(){c();s()});var a=function(){var p=document.querySelector('#movie_player,#player')||document.body;if(p)o.observe(p,{childList:true,subtree:true,attributes:true})};document.body?a():document.addEventListener('DOMContentLoaded',a,{once:true})})();";

    // ── Chrome spoofing ──
    private static final String SPOOF_SCRIPT = "(function(){if(window.__DT_SPOOFED__)return;window.__DT_SPOOFED__=true;try{Object.defineProperty(navigator,'webdriver',{get:function(){return false}})}catch(e){}try{Object.defineProperty(navigator,'languages',{get:function(){return['en-US','en']}})}catch(e){}try{Object.defineProperty(navigator,'vendor',{get:function(){return'Google Inc.'}})}catch(e){}try{Object.defineProperty(navigator,'platform',{get:function(){return'Win32'}})}catch(e){}})();";

    // ── Launch ──
    static void launch(AppCompatActivity from) {
        Intent i = new Intent(from, BrowserActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        from.startActivity(i);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Full screen
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        // Check incoming URL
        String startUrl = "https://www.google.com";
        if (getIntent() != null && getIntent().getData() != null) {
            startUrl = getIntent().getData().toString();
        }

        // Build UI
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xff1a1a2e);

        // ── Toolbar ──
        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setPadding(8, getStatusBarHeight() + 4, 8, 4);
        toolbar.setBackgroundColor(0xff16213e);

        btnBack = new ImageButton(this);
        btnBack.setImageResource(android.R.drawable.ic_media_previous);
        btnBack.setBackgroundColor(0);
        btnBack.setPadding(8, 8, 8, 8);
        btnBack.setOnClickListener(v -> { Tab t = activeTab(); if (t != null && t.webView.canGoBack()) t.webView.goBack(); });
        toolbar.addView(btnBack, new LinearLayout.LayoutParams(48, 48));

        btnForward = new ImageButton(this);
        btnForward.setImageResource(android.R.drawable.ic_media_next);
        btnForward.setBackgroundColor(0);
        btnForward.setPadding(8, 8, 8, 8);
        btnForward.setOnClickListener(v -> { Tab t = activeTab(); if (t != null && t.webView.canGoForward()) t.webView.goForward(); });
        toolbar.addView(btnForward, new LinearLayout.LayoutParams(48, 48));

        urlBar = new EditText(this);
        urlBar.setText(startUrl);
        urlBar.setTextColor(0xffffffff);
        urlBar.setHintTextColor(0xff888888);
        urlBar.setBackgroundResource(android.R.drawable.editbox_background);
        urlBar.setPadding(12, 4, 12, 4);
        urlBar.setTextSize(12);
        urlBar.setSingleLine(true);
        urlBar.setOnEditorActionListener((v, actionId, event) -> {
            navigateTo(v.getText().toString().trim());
            return true;
        });
        toolbar.addView(urlBar, new LinearLayout.LayoutParams(0, 44, 1));

        btnRefresh = new ImageButton(this);
        btnRefresh.setImageResource(android.R.drawable.ic_menu_compass);
        btnRefresh.setBackgroundColor(0);
        btnRefresh.setPadding(8, 8, 8, 8);
        btnRefresh.setOnClickListener(v -> { Tab t = activeTab(); if (t != null) t.webView.reload(); });
        toolbar.addView(btnRefresh, new LinearLayout.LayoutParams(48, 48));

        btnTabs = new ImageButton(this);
        btnTabs.setImageResource(android.R.drawable.ic_menu_gallery);
        btnTabs.setBackgroundColor(0);
        btnTabs.setPadding(8, 8, 8, 8);
        btnTabs.setOnClickListener(v -> showTabSwitcher());
        toolbar.addView(btnTabs, new LinearLayout.LayoutParams(48, 48));

        root.addView(toolbar, new LinearLayout.LayoutParams(-1, -2));

        // ── Progress bar ──
        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setVisibility(View.GONE);
        root.addView(progressBar, new LinearLayout.LayoutParams(-1, 3));

        // ── WebView container ──
        webViewContainer = new FrameLayout(this);
        root.addView(webViewContainer, new LinearLayout.LayoutParams(-1, -1));

        // ── Tab bar ──
        tabBar = new LinearLayout(this);
        tabBar.setOrientation(LinearLayout.HORIZONTAL);
        tabBar.setBackgroundColor(0xff0f3460);
        tabBar.setPadding(4, 4, 4, 4);
        tabBar.setHorizontalScrollBarEnabled(true);
        root.addView(tabBar, new LinearLayout.LayoutParams(-1, 48));

        // ── Bottom controls ──
        LinearLayout bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setBackgroundColor(0xff16213e);
        bottomBar.setPadding(8, 4, 8, 4);

        btnMenu = new ImageButton(this);
        btnMenu.setImageResource(android.R.drawable.ic_menu_more);
        btnMenu.setBackgroundColor(0);
        btnMenu.setPadding(8, 8, 8, 8);
        btnMenu.setOnClickListener(v -> showMenu());
        bottomBar.addView(btnMenu, new LinearLayout.LayoutParams(48, 44));

        TextView statusText = new TextView(this);
        statusText.setText("DT Browser v1.0");
        statusText.setTextColor(0xff888888);
        statusText.setTextSize(10);
        statusText.setPadding(8, 0, 8, 0);
        bottomBar.addView(statusText, new LinearLayout.LayoutParams(0, 44, 1));

        root.addView(bottomBar, new LinearLayout.LayoutParams(-1, 48));

        setContentView(root);

        // Create first tab
        createTab(startUrl);
    }

    // ── Tab management ──
    private Tab activeTab() {
        for (Tab t : tabs) if (t.id.equals(activeTabId)) return t;
        return null;
    }

    @SuppressLint({"SetJavaScriptEnabled", "ObsoleteSdkInt"})
    private Tab createTab(String url) {
        String id = UUID.randomUUID().toString().substring(0, 8);
        WebView wv = new WebView(this);

        // Settings
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setUserAgentString("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36");
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        if (Build.VERSION.SDK_INT >= 21) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true);
        }

        // WebViewClient with ad blocking
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                // Block ads
                if (isAdUrl(url)) {
                    return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream("".getBytes()));
                }
                return null;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                Tab t = findTabByView(view);
                if (t != null) {
                    t.url = url;
                    t.isLoading = true;
                    t.favicon = favicon;
                    urlBar.setText(url);
                    progressBar.setVisibility(View.VISIBLE);
                    updateTabBar();
                }
                // Inject Chrome spoofing
                view.evaluateJavascript(SPOOF_SCRIPT, null);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                Tab t = findTabByView(view);
                if (t != null) {
                    t.title = view.getTitle() != null ? view.getTitle() : url;
                    t.isLoading = false;
                    progressBar.setVisibility(View.GONE);
                    updateTabBar();
                }
                // Inject YouTube ad blocker
                if (url.contains("youtube.com") || url.contains("youtu.be")) {
                    view.evaluateJavascript(YT_AD_SCRIPT, null);
                }
                // Inject on page
                view.evaluateJavascript("window.__dtAndroid=true", null);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {}

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    return false; // Load in WebView
                }
                // External apps for other schemes
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(i);
                } catch (Exception e) {}
                return true;
            }
        });

        // WebChromeClient
        wv.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
            }

            @Override
            public void onReceivedTitle(WebView view, String title) {
                Tab t = findTabByView(view);
                if (t != null) { t.title = title; updateTabBar(); }
            }

            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                // Open popups in new tab
                WebView newWv = new WebView(BrowserActivity.this);
                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(newWv);
                resultMsg.sendToTarget();
                return true;
            }
        });

        // Touch/input
        wv.setFocusable(true);
        wv.setFocusableInTouchMode(true);
        wv.requestFocus();

        // Create tab
        Tab tab = new Tab(id, wv, url);
        tabs.add(tab);
        switchToTab(id);

        // Load URL
        wv.loadUrl(url);

        return tab;
    }

    private Tab findTabByView(WebView wv) {
        for (Tab t : tabs) if (t.webView == wv) return t;
        return null;
    }

    private void switchToTab(String id) {
        activeTabId = id;
        webViewContainer.removeAllViews();
        Tab t = activeTab();
        if (t != null) {
            webViewContainer.addView(t.webView, new FrameLayout.LayoutParams(-1, -1));
            t.webView.requestFocus();
            urlBar.setText(t.url);
            progressBar.setVisibility(t.isLoading ? View.VISIBLE : View.GONE);
        }
        updateTabBar();
    }

    private void closeTab(String id) {
        Tab t = null;
        for (Tab tab : tabs) { if (tab.id.equals(id)) { t = tab; break; } }
        if (t == null || tabs.size() <= 1) return;
        tabs.remove(t);
        webViewContainer.removeView(t.webView);
        t.webView.destroy();
        if (activeTabId.equals(id)) {
            switchToTab(tabs.get(tabs.size() - 1).id);
        }
    }

    private void updateTabBar() {
        tabBar.removeAllViews();
        for (Tab t : tabs) {
            TextView tv = new TextView(this);
            String title = t.title.isEmpty() ? "New Tab" : t.title;
            if (title.length() > 18) title = title.substring(0, 16) + "..";
            tv.setText(title);
            tv.setTextColor(t.id.equals(activeTabId) ? 0xff4fc3f7 : 0xff888888);
            tv.setTextSize(10);
            tv.setPadding(10, 8, 10, 8);
            tv.setBackgroundColor(t.id.equals(activeTabId) ? 0xff1a1a2e : 0xff0f3460);
            tv.setSingleLine(true);
            tv.setOnClickListener(v -> switchToTab(t.id));
            tv.setOnLongClickListener(v -> {
                closeTab(t.id);
                return true;
            });
            tabBar.addView(tv, new LinearLayout.LayoutParams(-2, -1));
        }
    }

    private void showTabSwitcher() {
        String[] items = new String[tabs.size()];
        for (int i = 0; i < tabs.size(); i++) {
            Tab t = tabs.get(i);
            items[i] = (t.id.equals(activeTabId) ? "✓ " : "  ") + (t.title.isEmpty() ? t.url : t.title);
        }
        new AlertDialog.Builder(this)
            .setTitle("Tabs (" + tabs.size() + ")")
            .setItems(items, (d, w) -> switchToTab(tabs.get(w).id))
            .setPositiveButton("+ New Tab", (d, w) -> createTab("https://www.google.com"))
            .show();
    }

    private void showMenu() {
        String[] items = {"New Tab", "Close Tab", "Share", "Exit"};
        new AlertDialog.Builder(this)
            .setTitle("Menu")
            .setItems(items, (d, w) -> {
                if (w == 0) createTab("https://www.google.com");
                else if (w == 1 && activeTab() != null) closeTab(activeTabId);
                else if (w == 2 && activeTab() != null) {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, activeTab().url);
                    startActivity(Intent.createChooser(i, "Share URL"));
                } else if (w == 3) finishAffinity();
            })
            .show();
    }

    // ── Navigation ──
    private void navigateTo(String input) {
        String url = input.trim();
        if (url.isEmpty()) return;
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            if (url.contains(".") && !url.contains(" ")) url = "https://" + url;
            else url = "https://www.google.com/search?q=" + Uri.encode(url);
        }
        urlBar.setText(url);
        Tab t = activeTab();
        if (t != null) t.webView.loadUrl(url);
    }

    // ── Ad blocking ──
    private boolean isAdUrl(String url) {
        if (url.contains("googlevideo.com")) {
            // Don't block googlevideo (causes black screen on YouTube)
            // Check if it's actually an ad segment
            if (url.contains("/videoplayback") && (url.contains("mn=ad") || url.contains("ad_") || url.contains("ctier"))) {
                // Allow it through, our JS script handles speed-through
                return false;
            }
            return false;
        }
        for (String host : AD_HOSTS) {
            if (url.contains(host)) return true;
        }
        // Block YouTube ad endpoints
        if (url.contains("youtube.com/pagead") || url.contains("youtube.com/api/stats/ads") ||
            url.contains("youtube.com/ptracking") || url.contains("youtube.com/youtubei/v1/log_event") ||
            url.contains("doubleclick.net/pagead/")) {
            return true;
        }
        return false;
    }

    // ── Back button ──
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            Tab t = activeTab();
            if (t != null && t.webView.canGoBack()) {
                t.webView.goBack();
                return true;
            }
            if (tabs.size() > 1) {
                closeTab(activeTabId);
                return true;
            }
            finishAffinity();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private int getStatusBarHeight() {
        int resId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return resId > 0 ? getResources().getDimensionPixelSize(resId) : 24;
    }

    @Override
    protected void onDestroy() {
        for (Tab t : tabs) {
            webViewContainer.removeView(t.webView);
            t.webView.destroy();
        }
        tabs.clear();
        super.onDestroy();
    }
}
